import UIKit

var number1 = 69
var number2 = 420
var number3 = 25
var number4 = 13
var number5 = 5
var number6 = 9000

1 + 1
1 * 1
1 - 1
1/1

print (number1 + number2)
print (number3 * number4)
print (number6 - number5)
print (number2/number5)
